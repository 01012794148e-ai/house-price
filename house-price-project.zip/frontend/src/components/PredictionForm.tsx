import { useEffect, useState, type FormEvent } from "react";
import { getLocations } from "../api/predictionClient";
import type { Furnishing, PredictionRequest, Transaction } from "../types/prediction";

interface Props {
  onSubmit: (payload: PredictionRequest) => void;
  isLoading: boolean;
}

const FURNISHING_OPTIONS: Furnishing[] = ["Furnished", "Semi-Furnished", "Unfurnished"];
const TRANSACTION_OPTIONS: Transaction[] = ["New Property", "Resale"];
const OWNERSHIP_OPTIONS = ["Freehold", "Leasehold", "Co-operative Society", "Power Of Attorney"];
const FACING_OPTIONS = ["North", "South", "East", "West", "North-East", "North-West", "South-East", "South-West"];

export default function PredictionForm({ onSubmit, isLoading }: Props) {
  const [locations, setLocations] = useState<string[]>([]);
  const [locationsError, setLocationsError] = useState<string | null>(null);

  const [location, setLocation] = useState("");
  const [carpetArea, setCarpetArea] = useState("");
  const [floorNum, setFloorNum] = useState("");
  const [bathroom, setBathroom] = useState("");
  const [balcony, setBalcony] = useState("");
  const [furnishing, setFurnishing] = useState<Furnishing>("Semi-Furnished");
  const [transaction, setTransaction] = useState<Transaction>("Resale");
  const [ownership, setOwnership] = useState(OWNERSHIP_OPTIONS[0]);
  const [facing, setFacing] = useState(FACING_OPTIONS[0]);

  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    getLocations()
      .then(setLocations)
      .catch(() => setLocationsError("Could not load locations from the API. Is the backend running?"));
  }, []);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);

    if (!location) {
      setFormError("Please select a location.");
      return;
    }
    const area = Number(carpetArea);
    if (!carpetArea || Number.isNaN(area) || area <= 0) {
      setFormError("Carpet area must be a number greater than 0.");
      return;
    }
    const floor = Number(floorNum);
    const baths = Number(bathroom);
    const balc = Number(balcony);
    if (floorNum === "" || Number.isNaN(floor) || floor < 0) {
      setFormError("Floor must be 0 or a positive number.");
      return;
    }
    if (bathroom === "" || Number.isNaN(baths) || baths < 0) {
      setFormError("Number of bathrooms must be 0 or more.");
      return;
    }
    if (balcony === "" || Number.isNaN(balc) || balc < 0) {
      setFormError("Number of balconies must be 0 or more.");
      return;
    }

    onSubmit({
      location,
      carpet_area_sqft: area,
      floor_num: floor,
      bathroom: baths,
      balcony: balc,
      furnishing,
      transaction,
      ownership,
      facing,
    });
  }

  return (
    <form onSubmit={handleSubmit} className="prediction-form">
      <div className="field">
        <label htmlFor="location">Location</label>
        <select
          id="location"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          disabled={locations.length === 0}
        >
          <option value="">-- Select a location --</option>
          {locations.map((loc) => (
            <option key={loc} value={loc}>
              {loc}
            </option>
          ))}
        </select>
        {locationsError && <p className="field-error">{locationsError}</p>}
      </div>

      <div className="field">
        <label htmlFor="carpetArea">Carpet Area (sqft)</label>
        <input
          id="carpetArea"
          type="number"
          min="1"
          value={carpetArea}
          onChange={(e) => setCarpetArea(e.target.value)}
        />
      </div>

      <div className="field">
        <label htmlFor="floorNum">Floor Number</label>
        <input
          id="floorNum"
          type="number"
          min="0"
          value={floorNum}
          onChange={(e) => setFloorNum(e.target.value)}
        />
      </div>

      <div className="field">
        <label htmlFor="bathroom">Bathrooms</label>
        <input
          id="bathroom"
          type="number"
          min="0"
          value={bathroom}
          onChange={(e) => setBathroom(e.target.value)}
        />
      </div>

      <div className="field">
        <label htmlFor="balcony">Balconies</label>
        <input
          id="balcony"
          type="number"
          min="0"
          value={balcony}
          onChange={(e) => setBalcony(e.target.value)}
        />
      </div>

      <div className="field">
        <label htmlFor="furnishing">Furnishing</label>
        <select
          id="furnishing"
          value={furnishing}
          onChange={(e) => setFurnishing(e.target.value as Furnishing)}
        >
          {FURNISHING_OPTIONS.map((opt) => (
            <option key={opt} value={opt}>
              {opt}
            </option>
          ))}
        </select>
      </div>

      <div className="field">
        <label htmlFor="transaction">Transaction</label>
        <select
          id="transaction"
          value={transaction}
          onChange={(e) => setTransaction(e.target.value as Transaction)}
        >
          {TRANSACTION_OPTIONS.map((opt) => (
            <option key={opt} value={opt}>
              {opt}
            </option>
          ))}
        </select>
      </div>

      <div className="field">
        <label htmlFor="ownership">Ownership</label>
        <select id="ownership" value={ownership} onChange={(e) => setOwnership(e.target.value)}>
          {OWNERSHIP_OPTIONS.map((opt) => (
            <option key={opt} value={opt}>
              {opt}
            </option>
          ))}
        </select>
      </div>

      <div className="field">
        <label htmlFor="facing">Facing</label>
        <select id="facing" value={facing} onChange={(e) => setFacing(e.target.value)}>
          {FACING_OPTIONS.map((opt) => (
            <option key={opt} value={opt}>
              {opt}
            </option>
          ))}
        </select>
      </div>

      {formError && <p className="form-error">{formError}</p>}

      <button type="submit" disabled={isLoading}>
        {isLoading ? "Predicting..." : "Predict Price"}
      </button>
    </form>
  );
}
