import { useState } from "react";
import { useNavigate } from "react-router-dom";
import PredictionForm from "../components/PredictionForm";
import { predictPrice } from "../api/predictionClient";
import type { PredictionRequest } from "../types/prediction";

export default function HomePage() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(payload: PredictionRequest) {
    setIsLoading(true);
    setError(null);
    try {
      const result = await predictPrice(payload);
      navigate("/result", { state: { predictedPrice: result.predicted_price } });
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong while contacting the prediction API."
      );
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="page">
      <h1>House Price Prediction</h1>
      <p className="subtitle">
        Enter the property details below to get an estimated price.
      </p>
      <PredictionForm onSubmit={handleSubmit} isLoading={isLoading} />
      {error && <p className="page-error">{error}</p>}
    </main>
  );
}
