import { Link, useLocation, Navigate } from "react-router-dom";

interface LocationState {
  predictedPrice?: number;
}

function formatIndianPrice(price: number): string {
  if (price >= 1e7) {
    return `₹ ${(price / 1e7).toFixed(2)} Cr`;
  }
  if (price >= 1e5) {
    return `₹ ${(price / 1e5).toFixed(2)} Lac`;
  }
  return `₹ ${price.toLocaleString("en-IN")}`;
}

export default function ResultPage() {
  const location = useLocation();
  const state = (location.state ?? {}) as LocationState;

  if (state.predictedPrice === undefined) {
    return <Navigate to="/" replace />;
  }

  return (
    <main className="page">
      <h1>Predicted Price</h1>
      <p className="predicted-price">{formatIndianPrice(state.predictedPrice)}</p>
      <p className="predicted-price-exact">
        (₹ {state.predictedPrice.toLocaleString("en-IN")})
      </p>
      <Link to="/" className="back-link">
        &larr; Predict another property
      </Link>
    </main>
  );
}
