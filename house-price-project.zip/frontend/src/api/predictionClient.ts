import type { PredictionRequest, PredictionResponse } from "../types/prediction";

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

export class ApiError extends Error {}

export async function getLocations(): Promise<string[]> {
  const response = await fetch(`${BASE_URL}/locations`);
  if (!response.ok) {
    throw new ApiError("Failed to load locations");
  }
  return response.json();
}

export async function predictPrice(
  payload: PredictionRequest
): Promise<PredictionResponse> {
  const response = await fetch(`${BASE_URL}/predict`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new ApiError(
      `Prediction request failed (${response.status}): ${detail}`
    );
  }

  return response.json();
}
