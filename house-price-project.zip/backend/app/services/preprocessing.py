import pandas as pd

from app.schemas.prediction import PredictionRequest

NUMERIC_FEATURES = ["carpet_area_sqft", "floor_num", "bathroom", "balcony"]
CATEGORICAL_FEATURES = ["location_grouped", "Furnishing", "Transaction", "Ownership", "facing"]


def request_to_dataframe(payload: PredictionRequest, allowed_locations: list[str]) -> pd.DataFrame:
    """
    Turn a validated PredictionRequest into a single-row DataFrame with exactly the
    column names the model's Pipeline was trained on. Unknown locations are mapped
    to "other", matching the notebook's top-N + "other" grouping strategy. Since the
    exported model is a full sklearn Pipeline, no manual scaling/encoding is needed
    here — the pipeline handles it.
    """
    location = payload.location if payload.location in allowed_locations else "other"

    row = {
        "carpet_area_sqft": payload.carpet_area_sqft,
        "floor_num": payload.floor_num,
        "bathroom": payload.bathroom,
        "balcony": payload.balcony,
        "location_grouped": location,
        "Furnishing": payload.furnishing,
        "Transaction": payload.transaction,
        "Ownership": payload.ownership,
        "facing": payload.facing,
    }

    return pd.DataFrame([row], columns=NUMERIC_FEATURES + CATEGORICAL_FEATURES)
