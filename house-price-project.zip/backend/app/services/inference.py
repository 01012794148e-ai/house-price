import json
import logging

import joblib
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class ModelService:
    """
    Wraps the exported scikit-learn Pipeline. Loaded once at app startup
    (see app/main.py lifespan) rather than on every request.
    """

    def __init__(self, model_path: str, locations_path: str):
        logger.info("Loading model from %s", model_path)
        self.model = joblib.load(model_path)

        logger.info("Loading allowed locations from %s", locations_path)
        with open(locations_path) as f:
            self.allowed_locations: list[str] = json.load(f)

    def predict(self, row: pd.DataFrame) -> float:
        # The model was trained on log1p(price), so we invert with expm1.
        log_pred = self.model.predict(row)[0]
        price = float(np.expm1(log_pred))
        return price
