from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "House Price Prediction API"
    cors_origins: str = "http://localhost:5173"
    model_path: str = "models/house_price.pkl"
    locations_path: str = "models/locations.json"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


settings = Settings()
