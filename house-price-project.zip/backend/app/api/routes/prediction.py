from fastapi import APIRouter, Request

from app.schemas.prediction import HealthResponse, PredictionRequest, PredictionResponse
from app.services.preprocessing import request_to_dataframe

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(status="ok")


@router.post("/predict", response_model=PredictionResponse)
def predict(payload: PredictionRequest, request: Request) -> PredictionResponse:
    model_service = request.app.state.model_service
    row = request_to_dataframe(payload, model_service.allowed_locations)
    price = model_service.predict(row)
    return PredictionResponse(predicted_price=round(price, 2))


@router.get("/locations")
def locations(request: Request) -> list[str]:
    """Convenience endpoint so the frontend can populate the location dropdown."""
    model_service = request.app.state.model_service
    return model_service.allowed_locations
