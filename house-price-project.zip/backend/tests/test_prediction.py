from fastapi.testclient import TestClient

from app.main import app

VALID_PAYLOAD = {
    "location": "thane",
    "carpet_area_sqft": 650,
    "floor_num": 4,
    "bathroom": 2,
    "balcony": 1,
    "furnishing": "Semi-Furnished",
    "transaction": "Resale",
    "ownership": "Freehold",
    "facing": "East",
}


def test_health():
    with TestClient(app) as client:
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json() == {"status": "ok"}


def test_predict_happy_path():
    with TestClient(app) as client:
        response = client.post("/predict", json=VALID_PAYLOAD)
        assert response.status_code == 200
        body = response.json()
        assert "predicted_price" in body
        assert isinstance(body["predicted_price"], (int, float))
        assert body["predicted_price"] > 0


def test_predict_invalid_input():
    invalid_payload = dict(VALID_PAYLOAD)
    invalid_payload["carpet_area_sqft"] = -100  # must be > 0

    with TestClient(app) as client:
        response = client.post("/predict", json=invalid_payload)
        assert response.status_code == 422


def test_predict_unknown_location_falls_back_to_other():
    payload = dict(VALID_PAYLOAD)
    payload["location"] = "some-city-not-in-training-data"

    with TestClient(app) as client:
        response = client.post("/predict", json=payload)
        assert response.status_code == 200
